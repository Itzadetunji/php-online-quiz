<?php 
    include "header.php";
 ?>
        <div class="row" style="">

            <div class="col-lg-6 col-lg-push-3" style="min-height: 500px; background-color: white;">
                tunji detu
            </div>

        </div>
<?php 
    include "footer.php";
 ?>