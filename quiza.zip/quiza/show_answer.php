<?php 
	session_start();
	include "connection.php";
 ?>
<?php 
	$category=$_GET["category"];
    $res=mysqli_query($link, "select * from questions");
    while ($row=mysqli_fetch_array($res)) {
        $question_no=$row["question_no"];
        $question=$row["question"];
        $opt1=$row["opt1"];
        $opt2=$row["opt2"];
        $opt3=$row["opt3"];
        $opt4=$row["opt4"];
        $answer=$row["answer"];
    }
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 	<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <form name="form1" action="" method="post">
                        <div class="card-body">
                            <div class="col-lg-6">
                                <?php
                                $count=0; 
                                $res=mysqli_query($link, "select * from questions");
                                while ($row=mysqli_fetch_array($res)) {
                                    $count=$count+1;
                                    ?>
                                    <table class="table table-bordered">
                                    <tr>
                                        <th scope="row"><?php echo $count; ?></th>
                                        <td><?php echo $row["question_no"]; ?></td>
                                        <td><?php echo $row["question"]; ?></td>
                                        <td><?php echo $row["answer"]; ?></td>
                                    </tr>
                                </table>
                                    <?php
                                }
                             ?>
                             <?php
			                	$count=0; 
			                	$res=mysqli_query($link, "select * from questions");
			                	$bet=mysqli_query($link, "select * from exam_results where username='$_SESSION[username]' order by id desc");
			                 	$count=mysqli_num_rows($res);

			                 	if ($count==0) {
			                 		?>
			                 		<center>
			                 			<h1>No results Found</h1>
			                 		</center>
			                 		<?php
			                 	}
			                 	else{
			                 		echo "<table class='table table-bordered'>";
			                 		echo "<tr style='background-color:#006df0; color:white;'>";
			                 		echo "<th>";	echo "username";	echo "</th>";
			                 		echo "<th>";	echo "exam type";	echo "</th>";
			                 		echo "<th>";	echo "total questions";	echo "</th>";
			                 		echo "</tr>";
			                 		while ($row=mysqli_fetch_array($res)) {
			                 			echo "<tr>";
				                 		echo "<td>";	echo $row["question_no"];	echo "</td>";
				                 		echo "<td>";	echo $row["question"];	echo "</td>";
				                 		echo "<td>";	echo $row["answer"];	echo "</td>"; 
				                 		echo "</tr>";
			                 		}
			                 		echo "</table>";
			                 	}
			                 ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
 </body>
 </html>